// app/[locale]/page.tsx
// Skopiuj ten plik do swojego projektu

import HomePage from "@/components/HomePage";

export default function Page() {
  return <HomePage />;
}

// Opcjonalnie: metadata dla SEO
export const metadata = {
  title: "Porównaj oferty internetu | DostawcyInternetu.pl",
  description:
    "Sprawdź dostępność światłowodu, kabla i internetu mobilnego pod Twoim adresem. Porównaj oferty Orange, Play, UPC, Vectra i innych operatorów.",
  openGraph: {
    title: "Porównaj oferty internetu | DostawcyInternetu.pl",
    description: "Sprawdź dostępność internetu pod Twoim adresem",
    type: "website",
  },
};
