"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Header from "./Header";
import Footer from "./Footer";
import MapFacade from "./MapFacade";
import HomeSearchBox from "./HomeSearchBox";

export default function HomePage() {
  const router = useRouter();
  const [isSearching, setIsSearching] = useState(false);

  const handleAddressSelect = (address: {
    miejscowosc: string;
    ulica?: string;
    nr?: string;
    slug: string;
  }) => {
    setIsSearching(true);
    
    // Buduj URL
    let url = `/internet/${address.slug}`;
    if (address.ulica) {
      const ulicaSlug = address.ulica.toLowerCase().replace(/\s+/g, "-");
      url += `/${ulicaSlug}`;
      if (address.nr) {
        url += `/${address.nr}`;
      }
    }
    
    router.push(url);
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      {/* Hero section z mapą jako tłem */}
      <main className="flex-1 relative">
        {/* Mapa jako tło */}
        <div className="absolute inset-0 z-0">
          <MapFacade />
        </div>
        
        {/* Overlay gradient dla czytelności */}
        <div className="absolute inset-0 z-10 bg-gradient-to-b from-white/70 via-transparent to-white/70" />
        
        {/* Floating content */}
        <div className="relative z-20 flex flex-col items-center justify-center min-h-[calc(100vh-80px-200px)] px-4">
          {/* Nagłówek */}
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-gray-900 mb-4">
              Sprawdź internet pod Twoim adresem
            </h1>
            <p className="text-lg md:text-xl text-gray-600 max-w-2xl mx-auto">
              Porównaj oferty światłowodu, kabla i internetu mobilnego od wszystkich operatorów
            </p>
          </div>
          
          {/* Szukajka */}
          <HomeSearchBox 
            onSelect={handleAddressSelect}
            isLoading={isSearching}
          />
          
          {/* Popularne miasta */}
          <div className="mt-8 text-center">
            <p className="text-sm text-gray-500 mb-3">Popularne miasta:</p>
            <div className="flex flex-wrap justify-center gap-2">
              {[
                { name: "Warszawa", slug: "warszawa" },
                { name: "Kraków", slug: "krakow" },
                { name: "Wrocław", slug: "wroclaw" },
                { name: "Poznań", slug: "poznan" },
                { name: "Gdańsk", slug: "gdansk" },
                { name: "Łódź", slug: "lodz" },
              ].map((city) => (
                <a
                  key={city.slug}
                  href={`/internet/${city.slug}`}
                  className="px-4 py-2 bg-white/80 hover:bg-white rounded-full text-sm font-medium text-gray-700 hover:text-blue-600 transition-colors shadow-sm hover:shadow"
                >
                  {city.name}
                </a>
              ))}
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
